from pathlib import Path
from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import get_settings
from .database import get_db
from .models import User
from .schemas import FeedbackRequest, UserInput
from .services.gemini_generator import generate_workout_gemini
from .services.gemini_flash_generator import generate_nutrition_tip_with_flash
from .services.updated_plan import update_workout_plan

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
router = APIRouter()

def save_user(db, data, plan, tip):
    user = db.scalar(select(User).where(User.user_id == data.user_id))
    if user is None:
        user = User(user_id=data.user_id, username=data.username, age=data.age,
                    weight=data.weight, goal=data.goal, intensity=data.intensity,
                    original_plan=plan, nutrition_tip=tip)
        db.add(user)
    else:
        user.username, user.age, user.weight = data.username, data.age, data.weight
        user.goal, user.intensity = data.goal, data.intensity
        user.original_plan, user.updated_plan = plan, None
        user.nutrition_tip = tip
    db.commit()
    db.refresh(user)
    return user

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate-workout", response_class=HTMLResponse)
def generate_form(request: Request, username: str = Form(...), user_id: str = Form(...),
                  age: int = Form(...), weight: float = Form(...), goal: str = Form(...),
                  intensity: str = Form(...), db: Session = Depends(get_db)):
    try:
        data = UserInput(username=username, user_id=user_id, age=age, weight=weight,
                         goal=goal, intensity=intensity)
        plan = generate_workout_gemini(**data.model_dump())
        tip = generate_nutrition_tip_with_flash(data.goal, data.age)
        user = save_user(db, data, plan, tip)
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "workout_plan": plan,
            "nutrition_tip": tip, "message": "Your 7-day plan was generated successfully."
        })
    except Exception as exc:
        return templates.TemplateResponse("index.html",
            {"request": request, "error": str(exc)}, status_code=400)

@router.post("/submit-feedback", response_class=HTMLResponse)
def feedback_form(request: Request, user_id: str = Form(...), feedback: str = Form(...),
                  db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.user_id == user_id))
    try:
        if not user:
            raise ValueError("User ID was not found.")
        req = FeedbackRequest(user_id=user_id, feedback=feedback)
        updated = update_workout_plan(user.updated_plan or user.original_plan,
                                      req.feedback, user.goal, user.intensity, user.age)
        user.updated_plan = updated
        db.commit()
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "workout_plan": updated,
            "nutrition_tip": user.nutrition_tip,
            "message": "Your plan was updated using your feedback."
        })
    except Exception as exc:
        return templates.TemplateResponse("result.html", {
            "request": request, "user": user, "workout_plan": user.updated_plan if user else "",
            "nutrition_tip": user.nutrition_tip if user else "",
            "error": str(exc)
        }, status_code=400)

@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, key: str = Query(""), db: Session = Depends(get_db)):
    if key != get_settings().admin_key:
        raise HTTPException(status_code=403, detail="Invalid admin key.")
    users = db.scalars(select(User).order_by(User.created_at.desc())).all()
    return templates.TemplateResponse("all_users.html", {"request": request, "users": users})

@router.get("/api/health")
def health():
    return {"status": "ok", "service": "FitBuddy"}

@router.post("/api/generate-workout")
def api_generate(data: UserInput, db: Session = Depends(get_db)):
    try:
        plan = generate_workout_gemini(**data.model_dump())
        tip = generate_nutrition_tip_with_flash(data.goal, data.age)
        save_user(db, data, plan, tip)
        return {"user_id": data.user_id, "username": data.username,
                "goal": data.goal, "intensity": data.intensity,
                "workout_plan": plan, "nutrition_tip": tip}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))

@router.post("/api/submit-feedback")
def api_feedback(data: FeedbackRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.user_id == data.user_id))
    if not user:
        raise HTTPException(status_code=404, detail="User ID was not found.")
    try:
        updated = update_workout_plan(user.updated_plan or user.original_plan,
                                      data.feedback, user.goal, user.intensity, user.age)
        user.updated_plan = updated
        db.commit()
        return {"user_id": user.user_id, "updated_plan": updated}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))

@router.get("/api/users")
def api_users(key: str = Query(""), db: Session = Depends(get_db)):
    if key != get_settings().admin_key:
        raise HTTPException(status_code=403, detail="Invalid admin key.")
    users = db.scalars(select(User).order_by(User.created_at.desc())).all()
    return [{
        "user_id": u.user_id, "username": u.username, "age": u.age,
        "weight": u.weight, "goal": u.goal, "intensity": u.intensity,
        "original_plan": u.original_plan, "updated_plan": u.updated_plan,
        "nutrition_tip": u.nutrition_tip, "created_at": u.created_at.isoformat()
    } for u in users]
