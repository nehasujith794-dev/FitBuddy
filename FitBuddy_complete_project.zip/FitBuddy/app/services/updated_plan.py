from google import genai
from google.genai import types
from ..config import get_settings

def update_workout_plan(original_plan, feedback, goal, intensity, age):
    settings = get_settings()
    if not settings.google_api_key:
        raise RuntimeError("GOOGLE_API_KEY is not configured. Add it to .env.")

    prompt = f"""
Update this FitBuddy 7-day plan.
Goal: {goal}
Intensity: {intensity}
Age: {age}

Original plan:
---BEGIN PLAN---
{original_plan}
---END PLAN---

Feedback:
---BEGIN FEEDBACK---
{feedback}
---END FEEDBACK---

Return a complete revised seven-day plan. Apply reasonable feedback while
preserving useful structure. Include rest/recovery. No diagnosis, medication,
dangerous challenges, extreme exercise, starvation, crash diets, or calorie
prescriptions. If under 18, avoid weight-loss/body-composition instructions.
"""
    response = genai.Client(api_key=settings.google_api_key).models.generate_content(
        model=settings.gemini_workout_model,
        contents=prompt,
        config=types.GenerateContentConfig(temperature=0.4, max_output_tokens=3500),
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty updated plan.")
    return text
