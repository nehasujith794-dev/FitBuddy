from google import genai
from google.genai import types
from ..config import get_settings

def generate_workout_gemini(username, age, weight, goal, intensity):
    settings = get_settings()
    if not settings.google_api_key:
        raise RuntimeError("GOOGLE_API_KEY is not configured. Add it to .env.")

    prompt = f"""
You are FitBuddy, a careful fitness-planning assistant.
Create a structured 7-day workout plan for:
Name: {username}
Age: {age}
Weight: {weight} kg
Goal: {goal}
Preferred intensity: {intensity}

Return Day 1 through Day 7. For every day include Focus, Warm-up,
Main workout with exercise names and sets/reps or duration, Rest/Recovery,
and Cool-down.

Safety rules:
- No diagnosis, medication, medical treatment, starvation, crash dieting,
  dangerous challenges, or extreme exercise.
- Include recovery/rest.
- If age is under 18, avoid weight-loss targets, calorie restriction,
  and body-composition instructions; emphasize general fitness, technique,
  enjoyment, recovery and qualified adult guidance.
- Do not claim the plan is medically approved.
"""
    response = genai.Client(api_key=settings.google_api_key).models.generate_content(
        model=settings.gemini_workout_model,
        contents=prompt,
        config=types.GenerateContentConfig(temperature=0.4, max_output_tokens=3500),
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty workout plan.")
    return text
