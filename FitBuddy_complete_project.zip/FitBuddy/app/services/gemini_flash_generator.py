from google import genai
from google.genai import types
from ..config import get_settings

def generate_nutrition_tip_with_flash(goal, age):
    settings = get_settings()
    if not settings.google_api_key:
        raise RuntimeError("GOOGLE_API_KEY is not configured. Add it to .env.")

    prompt = f"""
Give one concise practical nutrition or recovery tip.
Goal: {goal}; Age: {age}.
Focus on balanced meals, hydration, sleep and sustainable habits.
Do not prescribe calorie limits, fasting, supplements or medical treatment.
For users under 18, avoid dieting/weight-loss advice.
Maximum 120 words.
"""
    response = genai.Client(api_key=settings.google_api_key).models.generate_content(
        model=settings.gemini_tip_model,
        contents=prompt,
        config=types.GenerateContentConfig(temperature=0.3, max_output_tokens=300),
    )
    text = (response.text or "").strip()
    if not text:
        raise RuntimeError("Gemini returned an empty tip.")
    return text
