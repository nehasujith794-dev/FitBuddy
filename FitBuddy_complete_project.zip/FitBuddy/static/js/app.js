async function copyPlan(){
  const text=document.getElementById("workoutPlan")?.innerText||"";
  try{await navigator.clipboard.writeText(text);alert("Plan copied.");}
  catch(e){alert("Copy was not available. Select and copy the plan manually.");}
}
document.addEventListener("submit",e=>{
  const b=e.target.querySelector("button[type=submit]");
  if(b){b.disabled=true;b.dataset.originalText=b.textContent;b.textContent="Working...";}
});
